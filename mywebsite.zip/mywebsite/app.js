const express = require('express');
const path = require('path');
const app = express();

// Настройка шаблонизатора EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Настройка статической папки
app.use(express.static(path.join(__dirname, 'public')));

// Маршруты
app.get('/', (req, res) => {
  res.render('index', { title: "Оценщик и Риск-менеджер" });
});

app.get('/calculator', (req, res) => {
  res.render('calculator', { title: "Калькулятор оценщика" });
});

app.get('/gratitude', (req, res) => {
  res.render('gratitude', { title: "Благодарность преподавателю" });
});

app.get('/market_value_guide', (req, res) => {
  res.render('market_value_guide', { title: "Справочник рыночной стоимости" });
});

app.get('/notable_risk_managers', (req, res) => {
  res.render('notable_risk_managers', { title: "Жизнь замечательных риск-менеджеров" });
});

app.get('/notable_valuers', (req, res) => {
  res.render('notable_valuers', { title: "Жизнь замечательных оценщиков" });
});

app.get('/risk_encyclopedia', (req, res) => {
  res.render('risk_encyclopedia', { title: "Энциклопедия рисков" });
});

app.get('/risk_management_encyclopedia', (req, res) => {
  res.render('risk_management_encyclopedia', { title: "Энциклопедия риск-менеджмента" });
});

app.get('/valuers_insights', (req, res) => {
  res.render('valuers_insights', { title: "Взгляд оценщиков и риск-менеджеров" });
});

// Запуск сервера
const PORT = process.env.PORT || 3006;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
