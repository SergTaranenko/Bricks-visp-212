// animation.js
document.addEventListener('DOMContentLoaded', function () {
    var elements = document.querySelectorAll('.animate-on-scroll');
    function checkIfInView() {
      elements.forEach(function (element) {
        var rect = element.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          element.classList.add('in-view');
        }
      });
    }
    window.addEventListener('scroll', checkIfInView);
    checkIfInView();
  });
  