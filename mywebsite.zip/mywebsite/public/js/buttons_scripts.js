// buttons_scripts.js
document.addEventListener('DOMContentLoaded', function () {
    var buttons = document.querySelectorAll('.video_button a');
    buttons.forEach(function (button) {
      button.addEventListener('click', function (e) {
        alert('И это правильный выбор');
      });
    });
  });
  