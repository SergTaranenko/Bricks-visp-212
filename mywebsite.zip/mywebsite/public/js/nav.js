// nav.js
function nav_main(page) {
    var elements = document.querySelectorAll('.nav-link');
    elements.forEach(function (element) {
      if (element.href.includes(page)) {
        element.classList.add('active');
      } else {
        element.classList.remove('active');
      }
    });
  }
  