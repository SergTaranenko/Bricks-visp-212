// typing_script.js
document.addEventListener('DOMContentLoaded', function () {
    var typed = new Typed('.typed', {
      strings: ["Оценщиком", "Риск-менеджером", "Экспертом по оценке активов"],
      typeSpeed: 100,
      backSpeed: 50,
      loop: true
    });
  });
  